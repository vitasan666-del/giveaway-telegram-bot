# Giveaway Telegram Bot

Бот для розыгрышей с автотаймером и историей победителей.

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy?repo=https://github.com/YOUR_USERNAME/giveaway-telegram-bot)

## Команды

- /start — участвовать
- /set_timer <минут> — запуск таймера (админ)
- /winners — список победителей